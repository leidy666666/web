document.querySelector('#btn')
var aNombre=[],
    aCorreoelectronico=[],
    aAsunto=[],
    aMensaje=[];

var elementoBotonEnviar=document.querySelector('#btnEnviar');
